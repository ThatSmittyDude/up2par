up2par

This program is designed to update and fix corrupt windows files. The program uses bash commands to update applications using winget. It uses sfc to scan and fix corrupt windows files

===============================================================================================================

HOW TO USE:

**YOU MUST HAVE WINGET INSTALLED
**YOU MUST RUN THE PROGRAM AS AN ADMINISTRATOR

Simply right click on the Application [up2par.exe] 

Select 'Run as Administrator'

Wait for the command prompt to complete both of the bash executions

Select Ok for the windows disk cleanup and allow that to run

It is also recommended to do any windows updates that are available and then restart your machine

================================================================================================================

for any questions or con cerns contact me at ThatSmittyDude@outlook.com